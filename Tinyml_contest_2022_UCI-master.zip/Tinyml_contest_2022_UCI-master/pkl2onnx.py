from util import pytorch2onnx

# pytorch2onnx('./saved_models/IEGM_net_test.pkl', './saved_models/model_1', 1250)
pytorch2onnx('./saved_models/mobilenetv2_simple160on_16firstchannel_maxpool4to1_and_4to1_er1_correct_do0.5_epsilon_sepconv_first_stride2_no_slice_no_residule_dwstride2_preavgpool_2block256f_beta.pkl',
 './saved_models/test1', 1250)