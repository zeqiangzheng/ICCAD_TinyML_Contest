# How to validate the model with framework other than X-CUBE-AI on board

In the folder `framework_your-own`, we provide a compressed evaluation project named `TEST_OwnModel.zip`. Inside the project, the file `main.c` contains two function calls related to the evaluation on board.

<img src="https://raw.githubusercontent.com/AugustZTR/picbed/master/img/image-20220830123056603.png" alt="image-20220830123056603" style="zoom: 33%;" />

1. `MX_X_CUBE_AI_Process()` method contains content related to model initialization, such as loading of model activation values, etc.

2. `aiRun()` is the method of calling the model for inference.

When validating your own model, you can write your own model initialization and calling methods and replace them in your code. The rest of the code, including data reception, data transmission and serial communication, **MUST** be retained as a template. When loading data, the input data is a three-dimensional array `input[1][1250][1]`.

