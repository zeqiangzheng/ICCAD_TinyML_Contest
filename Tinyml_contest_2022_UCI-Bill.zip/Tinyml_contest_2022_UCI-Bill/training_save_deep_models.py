import argparse
import torch
import torchvision.transforms as transforms
from torch.utils.data import DataLoader, ConcatDataset
import torch.nn as nn
import torch.optim as optim
from help_code_demo import ToTensor, IEGM_DataSET
from help_code_demo import *
from models.model_1 import IEGMNet
from models.model_sqn import SqueezeNet
from models.model_vgg import MiniVGG
from models.model_vgg2 import vgg
from sklearn.model_selection import KFold

def main():
    # Hyperparameters
    BATCH_SIZE = args.batch_size
    BATCH_SIZE_TEST = args.batch_size
    LR = args.lr
    EPOCH = args.epoch
    SIZE = args.size
    path_data = args.path_data
    path_indices = args.path_indices
    k_fold = args.k_fold

    # Instantiating NN
    net = vgg()
    net.train()
    net = net.float().to(device)

    # Start dataset loading
    trainset = IEGM_DataSET(root_dir=path_data,
                            indice_dir=path_indices,
                            mode='train', 
                            size=SIZE,
                            transform=transforms.Compose([ToTensor()]))

    #trainloader = DataLoader(trainset, batch_size=BATCH_SIZE, shuffle=True, num_workers=0)

    testset = IEGM_DataSET(root_dir=path_data,
                           indice_dir=path_indices,
                           mode='test',
                           size=SIZE,
                           transform=transforms.Compose([ToTensor()]))

    #testloader = DataLoader(testset, batch_size=BATCH_SIZE_TEST, shuffle=True, num_workers=0)

    dataset = ConcatDataset([trainset])

    kfold = KFold(n_splits = k_fold, shuffle = True)
    print("Training Dataset loading finish.")


    print("Start training")
    cv_test_acc = []
    cv_test_loss = []
    for fold, (train_ids, test_ids) in enumerate(kfold.split(dataset)):
        #train_sub = torch.utils.data.SubsetRandomSampler(train_ids)
        #test_sub = torch.utils.data.SubsetRandomSampler(test_ids)
        trainloader = DataLoader(dataset, batch_size=BATCH_SIZE, shuffle=True)
        testloader = DataLoader(dataset, batch_size=BATCH_SIZE, shuffle=True)
        criterion = Fbeta_Loss()
        optimizer = optim.Adam(net.parameters(), lr=LR)
        epoch_num = EPOCH

        Train_loss = []
        Train_acc = []
        Test_loss = []
        Test_acc = []

        # create logger for ploting
        best_f_beta_loss = 1
        file_complete = creating_path("Result","logs", args.model,
                                  file_name=args.model + args.comment + str(args.batch_size) + args.loss + str(k_fold), extension='log')
        logger_complete = create_logger("complete", file_complete)
        print("K=%d" % (fold))

        for epoch in range(epoch_num):  # loop over the dataset multiple times (specify the #epoch)
            running_loss = 0.0
            correct = 0.0
            train_accuracy = 0.0        
            total = 0.0
            i = 0
            print(f'Starting epoch {epoch+1}')
            for j, data in enumerate(trainloader, 0):
                inputs, labels = data['IEGM_seg'], data['label']
                inputs = inputs.float().to(device)
                labels = labels.to(device)

                optimizer.zero_grad()
                outputs = net(inputs)
                loss = criterion(outputs, labels)
                loss.backward()
                optimizer.step()

                _, predicted = torch.max(outputs.data, 1)
                correct += (predicted == labels).sum()
                total += labels.size(0)
                running_loss += loss.item()
                i += 1

            train_accuracy = correct / total
            Train_loss = running_loss / i
            print('K = %d, [Epoch, Batches] is [%d, %5d] \nTrain Acc: %.5f Train loss: %.5f' %
                    (fold, epoch + 1, i, train_accuracy, Train_loss))

            running_loss = 0.0
            test_accuracy = 0.0

            correct = 0.0
            total = 0.0
            i = 0.0
            running_loss_test = 0.0
            print('Starting testing')
            for data_test in testloader:
                net.eval()
                IEGM_test, labels_test = data_test['IEGM_seg'], data_test['label']
                IEGM_test = IEGM_test.float().to(device)
                labels_test = labels_test.to(device)
                outputs_test = net(IEGM_test)
                _, predicted_test = torch.max(outputs_test.data, 1)
                total += labels_test.size(0)
                correct += (predicted_test == labels_test).sum()

                loss_test = criterion(outputs_test, labels_test)
                running_loss_test += loss_test.item()
                i += 1
            test_accuracy = (correct / total).item()
            Test_loss = running_loss_test / i
            print('Test Acc: %.5f Test Loss: %.5f' % (test_accuracy, Test_loss))



            if best_f_beta_loss > Test_loss:
                best_f_beta_loss = Test_loss
                torch.save(net, './saved_models/' + args.model + args.comment + str(args.batch_size) + args.loss +  str(fold) +'.pkl')
                torch.save(net.state_dict(), './saved_models/' + args.model + args.comment + str(args.batch_size)  + args.loss + str(fold) + '_state_dict.pkl')

            cur_lr = optimizer.param_groups[0]['lr']
            msg = ('Epoch: [{0}]\t'
                        'LR:[{1}]\t'
                        'Train_acc {2}\t'
                        'Train_loss {3}\t'
                        'Test_acc {4}\t'
                        'Test_loss {5}\t'
                        )
            logger_complete.info(msg.format(epoch+1, cur_lr, train_accuracy, Train_loss, test_accuracy, Test_loss))
        cv_test_acc.append(test_accuracy)
        cv_test_loss.append(Test_loss)
    sum1 = 0.0
    sum2 = 0.0

    print(cv_test_loss)
    closer_logger(logger_complete)
    print('Finish training')


if __name__ == '__main__':
    argparser = argparse.ArgumentParser()
    argparser.add_argument('--epoch', type=int, help='epoch number', default=100)
    argparser.add_argument('--lr', type=float, help='learning rate', default=0.0001)
    argparser.add_argument('--batch_size', type=int, help='total batchsz for traindb', default=256)
    argparser.add_argument('--cuda', type=int, default=0)
    argparser.add_argument('--size', type=int, default=1250)
    argparser.add_argument('--path_data', type=str, default='/home/haochx5/tinyml/tinyml_contest_data_training/')
    argparser.add_argument('--path_indices', type=str, default='./data_indices')
    argparser.add_argument('--path_net', type=str, default='./saved_models/')
    argparser.add_argument('--model', type=str, default='vgg')
    argparser.add_argument('--loss', type=str, default='f_beta')
    argparser.add_argument('--comment', type=str, default='1172_')
    argparser.add_argument('--k_fold', type=int, default='5')
    args = argparser.parse_args()

    if torch.cuda.is_available():    
        device = torch.device("cuda:" + str(args.cuda))
    else:
        device = 'cpu'

    print("device is --------------", device)

    main()

