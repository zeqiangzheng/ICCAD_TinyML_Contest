import tensorflow as tf
import numpy as np
import csv
import os
import sys
import shutil
import pathlib
import logging

#np.set_printoptions(threshold=sys.maxsize)

def loadCSV(csvf):
    """
    return a dict saving the information of csv
    :param splitFile: csv file name
    :return: {label:[file1, file2 ...]}
    """
    dictLabels = {}
    with open(csvf) as csvfile:
        csvreader = csv.reader(csvfile, delimiter=',')
        next(csvreader, None)  # skip (filename, label)
        for i, row in enumerate(csvreader):
            filename = row[0]
            label = row[1]

            # append filename to current label
            if label in dictLabels.keys():
                dictLabels[label].append(filename)
            else:
                dictLabels[label] = [filename]
    return dictLabels


def txt_to_numpy(filename, row):
    file = open(filename)
    lines = file.readlines()
    datamat = np.arange(row, dtype=float)
    row_count = 0
    for line in lines:
        line = line.strip().split(' ')
        datamat[row_count] = line[0]
        row_count += 1

    return datamat

class ToTensor(object):
    def __call__(self, sample):
        text = sample['IEGM_seg']
        return {
            'IEGM_seg': tf.convert_to_tensor(text),
            'label': sample['label']
        }
      
class IEGM_DataSET():
    def __init__(self, root_dir, indice_dir, mode, size, tensor=None):
        self.root_dir = root_dir
        self.indice_dir = indice_dir
        self.size = size
        self.names_list = []
        self.tensor = tensor

        csvdata_all = loadCSV(os.path.join(self.indice_dir, mode + '_indice.csv'))
        #print(csvdata_all)
        for i, (k, v) in enumerate(csvdata_all.items()):
            self.names_list.append(str(k) + ' ' + str(v[0]))
            #print(self.names_list)

    def __len__(self):
        return len(self.names_list)

    def __getitem__(self, idx):
        text_path = self.root_dir + self.names_list[idx].split(' ')[0]

        if not os.path.isfile(text_path):
            print(text_path + 'does not exist')
            return None

        IEGM_seg = txt_to_numpy(text_path, self.size).reshape(1, self.size, 1)
        label = int(self.names_list[idx].split(' ')[1])
        '''train_data_list = []
        train_label_list = []
        train_data_list.append(IEGM_seg)
        train_label_list.append(label)
        print(train_data_list)
        print(train_label_list)
        sample = {'IEGM_seg': IEGM_seg, 'label': label}'''
        
        return IEGM_seg,label
        
def main():
    
    # Start dataset loading
    trainset = IEGM_DataSET(root_dir='/home/shininy/tinyML_contest/Tinyml_git/tinyml_contest_data_training/',
                            indice_dir='/home/shininy/tinyML_contest/Tinyml_git/data_indices/',
                            mode='train',
                            size=1250,
                            tensor=ToTensor())
                            
    train_data_list = []
    train_label_list = []
    print(len(trainset))
    #for i in range(len(trainset)):
    for i in range(5000):
        #print(trainset[i])
        train_data_list.append(trainset[i][0])
        train_label_list.append(trainset[i][1])
    #print(train_data_list)
    #print(train_label_list)
    
    data_tensor = tf.convert_to_tensor(train_data_list)
    label_tensor = tf.convert_to_tensor(train_label_list)
    #print(data_tensor)
    #print(label_tensor)
    
    train_loader = tf.data.Dataset.from_tensor_slices((train_data_list, train_label_list))
    
    loss=tf.keras.losses.categorical_crossentropy
    optimizer=tf.keras.optimizers.Adam(learning_rate=0.0001)
     
    model = tf.keras.models.Sequential()
    model.add(tf.keras.layers.Conv2D(filters=2,
                                     kernel_size=(3, 1),
                                     strides=(1, 1),
                                     padding='same', #?
                                     activation=tf.keras.activations.relu,
                                     input_shape=(1, 1250, 1)))
    model.add(tf.keras.layers.MaxPool2D(pool_size=(1, 5), ###(5, 1) or (1, 5)?
                                        strides=(1, 5))) ###(5, 1) or (1, 5)?
    model.add(tf.keras.layers.Conv2D(filters=4,
                                     kernel_size=(3, 1),
                                     strides=(1, 1),
                                     padding='same',
                                     activation=tf.keras.activations.relu))
    model.add(tf.keras.layers.MaxPool2D(pool_size=(1, 5), ###(5, 1) or (1, 5)?
                                        strides=(1, 5))) ###(5, 1) or (1, 5)?
    model.add(tf.keras.layers.Conv2D(filters=8,
                                     kernel_size=(3, 1),
                                     strides=(1, 1),
                                     padding='same',
                                     activation=tf.keras.activations.relu))
    model.add(tf.keras.layers.Conv2D(filters=8,
                                     kernel_size=(3, 1),
                                     strides=1,
                                     padding='same',
                                     activation=tf.keras.activations.relu))
    model.add(tf.keras.layers.MaxPool2D(pool_size=(1, 5), ###(5, 1) or (1, 5)?
                                        strides=(1, 5))) ###(5, 1) or (1, 5)?
    model.add(tf.keras.layers.Flatten())
    model.add(tf.keras.layers.Dense(units=9,
                                    activation=tf.keras.activations.relu))
    model.add(tf.keras.layers.Dense(units=2,
                                    activation=None))
    model.summary()
    model.compile(optimizer='adam',
              loss=tf.keras.losses.SparseCategoricalCrossentropy(from_logits=True),
              metrics=['accuracy'])
    
    history = model.fit(data_tensor, label_tensor, epochs = 2000, batch_size = 64)
    
    tf.keras.models.save_model(model, "./trained_model")
    
    converter = tf.lite.TFLiteConverter.from_saved_model("./trained_model")
    tflite_model = converter.convert()
    
    with open('model.tflite', 'wb') as f:
        f.write(tflite_model)
    
if __name__ == '__main__':
    main()