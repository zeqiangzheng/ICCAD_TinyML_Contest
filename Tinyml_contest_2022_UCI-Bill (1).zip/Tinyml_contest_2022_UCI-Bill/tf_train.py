import argparse
from ast import arg
from multiprocessing.sharedctypes import Value
import os
from help_code_demo import *
import tensorflow as tf
# import keras as K
from tensorflow.keras import backend as K
import matplotlib.pyplot as plt
import numpy as np
#from tensorflow.keras import layers
from sklearn.preprocessing import OneHotEncoder
import torch.nn.functional as F
from copy import deepcopy
#os.environ["CUDA_VISIBLE_DEVICES"] = "-1"
from sklearn.model_selection import KFold
from itertools import chain

def tfload():
   
    x_train, y_train, x_test, y_test, x_dict , y_dict= load_tensorflow_data('C:/tinyml/tinyml_contest_data_training/', 'C:/tinyml/data_indices')

    #x_train = f.cotnvert_to_tensor(x_train, dtype=tf.float32)
    #y_train = tf.convert_to_tensor(y_train, dtype=tf.float32)
    #x_test = tf.convert_to_tensor(x_test, dtype=tf.float32)
    #y_train = tf.squeeze(y_train)
    #y_test = tf.convert_to_tensor(y_test, dtype=tf.float32)
    return(x_train, y_train, x_test, y_test, x_dict ,y_dict)

def tfload2():
    
    trainset = IEGM_DataSET(root_dir='/home/haochx5/tinyml/tinyml_contest_data_training/',
                                indice_dir='./data_indices',
                                mode='train',
                                size=1250,
                                tensor=ToTensor())
                                
    train_data_list = []
    train_label_list = []
    print(len(trainset))
        #for i in range(len(trainset)):
    for i in range(len(trainset)):
            #print(trainset[i])
        train_data_list.append(trainset[i][0])
        train_label_list.append(trainset[i][1])

    x_train = tf.convert_to_tensor(train_data_list)

    #y_train = tf.convert_to_tensor(train_label_list)
    return(x_train, train_label_list)

    """
    return a dict saving the information of csv
    :param splitFile: csv file name
    :return: {label:[file1, file2 ...]}
    """
    dictLabels = {}
    with open(csvf) as csvfile:
        csvreader = csv.reader(csvfile, delimiter=',')
        next(csvreader, None)  # skip (filename, label)
        for i, row in enumerate(csvreader):
            filename = row[0]
            label = row[1]

            # append filename to current label
            if label in dictLabels.keys():
                dictLabels[label].append(filename)
            else:
                dictLabels[label] = [filename]
    return dictLabels

def fbeta_weighted(true, pred): #shapes (batch, 4)
    beta = 2
    #for metrics include these two lines, for loss, don't include them
    #these are meant to round 'pred' to exactly zeros and ones
    #predLabels = K.argmax(pred, axis=-1)
    #pred = K.one_hot(predLabels, 4) 

    ground_positives = K.sum(true, axis=0) + K.epsilon()       # = TP + FN
    pred_positives = K.sum(pred, axis=0) + K.epsilon()         # = TP + FP
    true_positives = K.sum(true * pred, axis=0) + K.epsilon()  # = TP
        #all with shape (4,)
    
    precision = true_positives / pred_positives 
    recall = true_positives / ground_positives
        #both = 1 if ground_positives == 0 or pred_positives == 0
        #shape (4,)

    # f_bata = 2 * (precision * recall) / (precision + recall + K.epsilon())
        #still with shape (4,)
    
    f_bata = (1 + beta**2) * ((precision * recall) / ((beta**2 * precision) + recall + K.epsilon()))

    weighted_fbeta = f_bata * ground_positives / K.sum(ground_positives) 
    weighted_fbeta = K.sum(weighted_fbeta)

    
    return 1 - weighted_fbeta #for metrics, return only 'weighted_fbeta'

def fbeta_loss(y_true,y_pred):
    beta = 2
    #tf.print('0', y_true)
    y_true = tf.squeeze(y_true)
    y_true = K.cast(y_true, 'int32')
    #tf.print('1', y_true)
    y_true = K.one_hot(y_true, 2)
    y_pred = K.softmax(y_pred, axis=1)
    #tf.print('2',y_true)
    #tf.print('3',y_pred)
    #tf.print('4',y_true * y_pred)
    #tf.print('5',K.sum(y_true * y_pred, axis=0))
    #y_true = K.cast(y_true, 'float')
    #y_pred = K.cast(y_pred, 'float')   
    tp = K.sum(y_true * y_pred, axis=0)
    tn = K.sum((1 - y_true) * (1 - y_pred), axis=0)
    fp = K.sum((1 - y_true) * y_pred, axis=0)
    fn = K.sum(y_true * (1 - y_pred), axis=0)

    precision = tp / (tp + fp + K.epsilon())
    recall = tp / (tp + fn + K.epsilon())
    #tf.print('precision',precision)
    #tf.print('recall',recall)
    # precision = tp / (tp + fp)
    # recall = tp / (tp + fn)

    f_bata = (1 + beta**2) * ((precision * recall) / (((beta**2) * precision) + recall + K.epsilon()))
    #tf.print('f_bata',f_bata)
    # f_bata = (1+beta**2) * (precision * recall) / ((beta**2)*precision + recall)
    #f_bata = tf.where(tf.math.is_nan(f_bata), tf.zeros_like(f_bata), f_bata)
    #tf.print('fbetaloss')
    #tf.print(1 - np.mean(f_bata))
    #ff=np.array(f_bata)
    return 1 - tf.math.reduce_mean(f_bata)

def fbeta_test(y_true, y_pred):
    metric = tfa.metrics.FBetaScore(num_classes=2, beta=2.0)

    print(y_true[0][0])
    print(y_true[1][0])
    print(y_pred[0][0])
    print(y_pred[1][0])
    print(tf.shape(y_true[1]))
    print(tf.shape(y_pred[1]))
    #y_true = K.one_hot(y_true, 2)
    y_pred = K.softmax(y_pred, axis=1)
    print(tf.shape(y_true))
    print(tf.shape(y_pred))
    metric.update_state(y_true, y_pred)
    fb = metric.result()
    return 1-fb

def fbeta(y_true,y_pred):
    beta = 2
    y_true = tf.squeeze(y_true)
    y_true = K.cast(y_true,'int32')
    y_true = K.one_hot(y_true, 2)
    y_pred = K.softmax(y_pred, axis=1)
    #y_true = K.cast(y_true, 'float')
    #y_pred = K.cast(y_pred, 'float')   
    
    tp = K.sum(y_true * y_pred, axis=0)
    tn = K.sum((1 - y_true) * (1 - y_pred), axis=0)
    fp = K.sum((1 - y_true) * y_pred, axis=0)
    fn = K.sum(y_true * (1 - y_pred), axis=0)

    precision = tp / (tp + fp + K.epsilon())
    recall = tp / (tp + fn + K.epsilon())
    # precision = tp / (tp + fp)
    # recall = tp / (tp + fn)

    f_bata = (1 + beta**2) * ((precision * recall) / (((beta**2) * precision) + recall + K.epsilon()))
    # f_bata = (1+beta**2) * (precision * recall) / ((beta**2)*precision + recall)
    #f_bata = tf.where(tf.math.is_nan(f_bata), tf.zeros_like(f_bata), f_bata)


    return tf.math.reduce_mean(f_bata)

def f1_loss(y_true, y_pred):
    y_true = tf.squeeze(y_true)

    y_true = K.one_hot(y_true, 2)
    y_pred = K.softmax(y_pred, axis=1)

    tp = K.sum(K.cast(y_true*y_pred, 'float'), axis=0)
    tn = K.sum(K.cast((1-y_true)*(1-y_pred), 'float'), axis=0)
    fp = K.sum(K.cast((1-y_true)*y_pred, 'float'), axis=0)
    fn = K.sum(K.cast(y_true*(1-y_pred), 'float'), axis=0)

    p = tp / (tp + fp + K.epsilon())
    r = tp / (tp + fn + K.epsilon())

    f1 = 2*p*r / (p+r+K.epsilon())
    f1 = tf.where(tf.math.is_nan(f1), tf.zeros_like(f1), f1)

    
    return 1 - K.mean(f1)

def vgg_model2():
    model = tf.keras.models.Sequential()
    model.add(tf.keras.layers.Conv2D(filters=2,
                                     kernel_size=(3, 1),
                                     strides=(1, 1),
                                     padding='same', #?
                                     activation=tf.keras.activations.relu,
                                     input_shape=(1, 1250, 1)))
    model.add(tf.keras.layers.MaxPool2D(pool_size=(1, 5), ###(5, 1) or (1, 5)?
                                        strides=(1, 5))) ###(5, 1) or (1, 5)?
    model.add(tf.keras.layers.Conv2D(filters=4,
                                     kernel_size=(3, 1),
                                     strides=(1, 1),
                                     padding='same',
                                     activation=tf.keras.activations.relu))
    model.add(tf.keras.layers.MaxPool2D(pool_size=(1, 5), ###(5, 1) or (1, 5)?
                                        strides=(1, 5))) ###(5, 1) or (1, 5)?
    model.add(tf.keras.layers.Conv2D(filters=8,
                                     kernel_size=(3, 1),
                                     strides=(1, 1),
                                     padding='same',
                                     activation=tf.keras.activations.relu))
    model.add(tf.keras.layers.Conv2D(filters=8,
                                     kernel_size=(3, 1),
                                     strides=1,
                                     padding='same',
                                     activation=tf.keras.activations.relu))
    model.add(tf.keras.layers.MaxPool2D(pool_size=(1, 5), ###(5, 1) or (1, 5)?
                                        strides=(1, 5))) ###(5, 1) or (1, 5)?
    model.add(tf.keras.layers.Dropout(0.5))
    model.add(tf.keras.layers.Flatten())
    model.add(tf.keras.layers.Dense(units=9,
                                    activation=tf.keras.activations.relu))
    model.add(tf.keras.layers.Dense(units=2,
                                    activation=None))
    return model

def vgg_model():

    model = tf.keras.Sequential()
    
    model.add(tf.keras.layers.Conv2D(filters=2,
                                     kernel_size=(1, 3),
                                     strides=(1, 1),
                                     padding='same',
                                     activation=tf.keras.activations.relu,
                                     input_shape=(1, 1250, 1)))

    model.add(tf.keras.layers.MaxPool2D(pool_size=(1, 5),
                                        strides=(1, 5)))

    model.add(tf.keras.layers.Conv2D(filters=4,
                                     kernel_size=(1, 3),
                                     strides=(1, 1),
                                     padding='same',
                                     activation=tf.keras.activations.relu))

    model.add(tf.keras.layers.MaxPool2D(pool_size=(1, 5),
                                        strides=(1, 5)))

    model.add(tf.keras.layers.Conv2D(filters=8,
                                     kernel_size=(1, 3),
                                     strides=(1, 1),
                                     padding='same',
                                     activation=tf.keras.activations.relu))

    model.add(tf.keras.layers.Conv2D(filters=8,
                                     kernel_size=(1, 3),
                                     strides=1,
                                     padding='same',
                                     activation=tf.keras.activations.relu))

    model.add(tf.keras.layers.MaxPool2D(pool_size=(1, 5),
                                        strides=(1, 5)))

    model.add(tf.keras.layers.Dropout(0.5))
    model.add(tf.keras.layers.Flatten())

    model.add(tf.keras.layers.Dense(units=9,
                                    activation=tf.keras.activations.relu))
    model.add(tf.keras.layers.Dense(units=2,
                                    activation=None))

    return model

def model_evaluation(predict,y_test):
    test_label=deepcopy(predict)
    fp = 0
    fn = 0
    tp = 0
    tn = 0
    result=0
    for i in range(len(predict)):
        if test_label[i][0]>test_label[i][1]:
            result = 0
        else:
            result = 1
        if result == 0 and y_test[i] == 0:
            tn = tn + 1
        if result == 0 and y_test[i] == 1:
            fn = fn + 1
        if result == 1 and y_test[i] == 0:
            fp = fp + 1
        if result == 1 and y_test[i] == 1:
            tp = tp + 1
    total = tn + tp + fn + fp
    acc = (tp + tn) / total
    recall = tp / (tp + fn)
    precision = tp / (tp + fp)
    f1 = (1+2**2) * (precision * recall) / ((2**2)*precision + recall)
    print("F-B = ", f1)
    print("Sensitivity = ", recall)
    print("ACC = ", acc)
    print("Precision = ", precision)
    return f1


def main():
    (x_train, y_train, x_test, y_test, x_dict, y_dict)=tfload()

    fn_loss = fbeta_loss
    #fn_loss = tf.keras.losses.SparseCategoricalCrossentropy(from_logits=True)
    acc_per_fold = []
    loss_per_fold = []
    
    file_complete = creating_path("Result","logs", args.model,
                                  file_name=args.model + args.comment , extension='log')
    logger_complete = create_logger("complete", file_complete)
    
    num=0
    x_data = []
    y_data = []
    tmp = []
    tmp2 = []
    for data, label in zip(x_dict.values(), y_dict.values()):
        tmp.append(data)
        tmp2.append(label)
        num = num + 1
        # 60/6=10
        if num == 6 :
            num = 0
            # flatlist = []
            # for sublist in tmp:
            #     flatlist.append(sublist)
            # tmp = flatlist
            tmp = list(chain.from_iterable(tmp))
            tmp2 = list(chain.from_iterable(tmp2))
            x_data.append(tmp)
            y_data.append(tmp2)
            tmp = []
            tmp2 = []

    # 40% of data for training
    perc = 6

    for i in range(10):
        #k_fold
        tmp = []
        tmp2 = []
        q = 0
        for m in range(perc):
            q = i + m
            if q > 9:
                q = q - 10
            tmp.append(x_data[q])
            tmp2.append(y_data[q])
        x_train_val = list(chain.from_iterable(tmp))
        y_train_val = list(chain.from_iterable(tmp2))

        train_dataset = tf.data.Dataset.from_tensor_slices((x_train_val, y_train_val))
        train_dataset = train_dataset.shuffle(buffer_size=1024).batch(128)
        tmp = []
        tmp2 = []
        for j in range(10-perc):
            q = j + perc
            if q > 9:
                q = q - 10
            tmp.append(x_data[q])
            tmp2.append(y_data[q])

        x_test_val = tf.convert_to_tensor(list(chain.from_iterable(tmp)))
        y_test_val = tf.convert_to_tensor(list(chain.from_iterable(tmp2)))

        # val_dataset = tf.data.Dataset.from_tensor_slices((x_test_val, y_test_val))
        # val_dataset = val_dataset.batch(128)
       
        # TFLITE_FILE_PATH = './home/haochx5/tinyml/tf_model_large_1/saved_model.pb'
        # test_model = tf.keras.models.load_model(TFLITE_FILE_PATH)

        # y_predict=test_model.predict(x_test_val)
        # f_beta = model_evaluation(y_predict,y_test_val)
        # print("F_beta is ",f_beta)
        model = vgg_model()
        epochs = 30
        lr_schedule = tf.keras.optimizers.schedules.ExponentialDecay(
            initial_learning_rate=0.001,
            decay_steps=10000,
            decay_rate=0.9)
        optimizer = tf.keras.optimizers.Adam(learning_rate=lr_schedule)
        loss_fn = fbeta_loss
        train_acc_metric = tf.keras.metrics.SparseCategoricalAccuracy()
        val_acc_metric = tf.keras.metrics.SparseCategoricalAccuracy()
        batch_size = 128
        best_f_beta= 0
        model.compile(optimizer='adam', loss=loss_fn, metrics=["acc"])
        for epoch in range(epochs):
            print("\nStart of epoch %d" % (epoch + 1,))
            running_loss = 0
            # Iterate over the batches of the dataset.
            for step, (x_batch_train, y_batch_train) in enumerate(train_dataset):
                with tf.GradientTape() as tape:
                    logits = model(x_batch_train, training=True)
                    loss_value = loss_fn(y_batch_train, logits)
                grads = tape.gradient(loss_value, model.trainable_weights)
                optimizer.apply_gradients(zip(grads, model.trainable_weights))
                # Update training metric.
                train_acc_metric.update_state(y_batch_train, logits)
                running_loss += float(loss_value)

            print("Training loss at epoch: ", epoch+1, "is: ", running_loss/batch_size)
            train_acc = train_acc_metric.result()
            print("Training acc over epoch: %.4f" % (float(train_acc),))

            # Reset training metrics at the end of each epoch
            train_acc_metric.reset_states()

            # Run a validation loop at the end of each epoch.
            # for x_batch_val, y_batch_val in val_dataset:
            #     val_logits = model(x_batch_val, training=False)
            #     # Update val metrics
            #     val_acc_metric.update_state(y_batch_val, val_logits)
            # val_acc = val_acc_metric.result()
            # val_acc_metric.reset_states()
            # print("Validation acc: %.4f" % (float(val_acc),))



            y_predict=model.predict(x_test_val)
            print("Testing result at eopch ", epoch + 1)
            f_beta = model_evaluation(y_predict,y_test_val)
            print("F_beta is ",f_beta)

            msg = ('Epoch: [{0}]\t'
                        'FBeta:[{1}]\t'
                        'Train_acc {2}\t'
                        'Train_loss {3}\t'
                        )
            logger_complete.info(msg.format(epoch+1, f_beta, train_acc, running_loss/batch_size))
            if best_f_beta < f_beta:
                best_f_beta = f_beta
                # saved_model = deepcopy(model)
                # saved_model.compile(optimizer='adam', loss=loss_fn)
                #tf.keras.models.save_model(model, "./tf_model")
                #converter = tf.lite.TFLiteConverter.from_saved_model("./tf_model")
                # tflite_model = converter.convert()
                # with open('model.tflite', 'wb') as f:
                #     f.write(tflite_model)

    print(best_f_beta)


'''
    for kfold, (train_ids, test_ids) in enumerate (KFold(n_splits = 5, shuffle= True).split(x_train,y_train)): 
        x_train_val, x_test_val = x_train[train_ids], x_train[test_ids]
        y_train_val, y_test_val = y_train[train_ids], y_train[test_ids]

        model.compile(optimizer, loss = fn_loss, metrics=['acc'])
        print(train_ids)
        print('------------------------------------------------------------------------')
        print(f'Training for fold {kfold} ...')
        history=model.fit(x_train_val, y_train_val, batch_size = 256, epochs=50, validation_data = (x_test_val, y_test_val))

        scores = model.evaluate(x_test_val[test_ids], y_test_val[test_ids], verbose=0)
        print(f'Score for fold {kfold}: {model.metrics_names[0]} of {scores[0]}; {model.metrics_names[1]} of {scores[1]*100}%')
        y_predict=model.predict(x_test_val)
        tf.print('fbeta is:', model_evaluation(y_test_val, y_predict))
        acc_per_fold.append(scores[1] * 100)
        loss_per_fold.append(scores[0])

    # == Provide average scores ==
    print('------------------------------------------------------------------------')
    print('Score per fold')
    for i in range(0, len(acc_per_fold)):
        print('------------------------------------------------------------------------')
        print(f'> Fold {i+1} - Loss: {loss_per_fold[i]} - Accuracy: {acc_per_fold[i]}%')
    print('------------------------------------------------------------------------')
    print('Average scores for all folds:')
    print(f'> Accuracy: {np.mean(acc_per_fold)} (+- {np.std(acc_per_fold)})')
    print(f'> Loss: {np.mean(loss_per_fold)}')
    print('------------------------------------------------------------------------')

    #print(history.history)
    #print(model.evaluate(x_test, y_test))
    y_predict=model.predict(x_test)
    tf.print('fbeta is:', fbeta(y_test, y_predict))
    #tf.keras.models.save_model(model, "./tf_model67)
    #converter = tf.lite.TFLiteConverter.from_saved_model("./model6")
    #tflite_model = converter.convert()
    #tflite_model_files = pathlib.Path('./model6/model.tflite')
    #tflite_model_files.write_bytes(tflite_model)
    #with open('model.tflite', 'wb') as f:
    #    f.write(tflite_model)


    #metric = tf.metrics.FBetaScore(num_classes=2, beta=2.0)
    #metric.update_state(y_true, y_pred)
    #result = metric.result()
    #result.numpy()
'''
if __name__ == '__main__':
    argparser = argparse.ArgumentParser()
    argparser.add_argument('--epoch', type=int, help='epoch number', default=100)
    argparser.add_argument('--lr', type=float, help='learning rate', default=0.0001)
    argparser.add_argument('--batch_size', type=int, help='total batchsz for traindb', default=256)
    argparser.add_argument('--cuda', type=int, default=0)
    argparser.add_argument('--size', type=int, default=1250)
    argparser.add_argument('--path_data', type=str, default='C:/tinyml/tinyml_contest_data_training/')
    argparser.add_argument('--path_indices', type=str, default='./data_indices')
    argparser.add_argument('--path_net', type=str, default='./saved_models/')
    argparser.add_argument('--model', type=str, default='vgg')
    argparser.add_argument('--loss', type=str, default='f_beta')
    argparser.add_argument('--comment', type=str, default='60-40_')
    argparser.add_argument('--k_fold', type=int, default='10')
    args = argparser.parse_args()
    main()
