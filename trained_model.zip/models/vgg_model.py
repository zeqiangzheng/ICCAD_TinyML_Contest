import tensorflow as tf
#from config import *

def vgg_model():
    model = tf.keras.Sequential()
    
    model.add(tf.keras.layers.Conv2D(filters=2,
                                     kernel_size=(3, 1),
                                     strides=(1, 1),
                                     padding='same', #?
                                     activation=tf.keras.activations.relu,
                                     input_shape=(1, 1250, 1)))

    model.add(tf.keras.layers.MaxPool2D(pool_size=(5, 1),
                                        strides=(5, 1)))

    model.add(tf.keras.layers.Conv2D(filters=4,
                                     kernel_size=(3, 1),
                                     strides=(1, 1),
                                     padding='same',
                                     activation=tf.keras.activations.relu))

    model.add(tf.keras.layers.MaxPool2D(pool_size=(5, 1),
                                        strides=(5, 1)))

    model.add(tf.keras.layers.Conv2D(filters=8,
                                     kernel_size=(3, 1),
                                     strides=(1, 1),
                                     padding='same',
                                     activation=tf.keras.activations.relu))

    model.add(tf.keras.layers.Conv2D(filters=8,
                                     kernel_size=(3, 1),
                                     strides=(1, 1),
                                     padding='same',
                                     activation=tf.keras.activations.relu))

    model.add(tf.keras.layers.MaxPool2D(pool_size=(5, 1),
                                        strides=(5, 1)))

    model.add(tf.keras.layers.Flatten())

    model.add(tf.keras.layers.Dense(units=9,
                                    activation=tf.keras.activations.relu))
    model.add(tf.keras.layers.Dense(units=2,
                                    activation=None))

    return model
