from help_code_demo import pytorch2onnx

pytorch2onnx('./saved_models/IEGM_net.pkl', './saved_models/model_1', 1250)