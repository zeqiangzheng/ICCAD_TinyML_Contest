import argparse
import os
from help_code_demo import *
import tensorflow as tf
# import keras as K
from tensorflow.keras import backend as K
import matplotlib.pyplot as plt
import numpy as np
from tensorflow.keras import layers
import tensorflow_addons as tfa
from sklearn.preprocessing import OneHotEncoder
import torch.nn.functional as F
from copy import deepcopy
#os.environ["CUDA_VISIBLE_DEVICES"] = "-1"

def tfload():
   
    x_train, y_train, x_test, y_test = load_tensorflow_data('./tinyml_contest_data_training/', './data_indices')

    x_train = tf.convert_to_tensor(x_train, dtype=tf.float32)
    #y_train = tf.convert_to_tensor(y_train, dtype=tf.float32)
    x_test = tf.convert_to_tensor(x_test, dtype=tf.float32)
    #y_train = tf.squeeze(y_train)
    #y_test = tf.convert_to_tensor(y_test, dtype=tf.float32)
    return(x_train, y_train, x_test, y_test)

def tfload2():
    
    trainset = IEGM_DataSET(root_dir='/home/haochx5/tinyml/tinyml_contest_data_training/',
                                indice_dir='./data_indices',
                                mode='train',
                                size=1250,
                                tensor=ToTensor())
                                
    train_data_list = []
    train_label_list = []
    print(len(trainset))
        #for i in range(len(trainset)):
    for i in range(len(trainset)):
            #print(trainset[i])
        train_data_list.append(trainset[i][0])
        train_label_list.append(trainset[i][1])

    x_train = tf.convert_to_tensor(train_data_list)

    #y_train = tf.convert_to_tensor(train_label_list)
    return(x_train, train_label_list)

    """
    return a dict saving the information of csv
    :param splitFile: csv file name
    :return: {label:[file1, file2 ...]}
    """
    dictLabels = {}
    with open(csvf) as csvfile:
        csvreader = csv.reader(csvfile, delimiter=',')
        next(csvreader, None)  # skip (filename, label)
        for i, row in enumerate(csvreader):
            filename = row[0]
            label = row[1]

            # append filename to current label
            if label in dictLabels.keys():
                dictLabels[label].append(filename)
            else:
                dictLabels[label] = [filename]
    return dictLabels

def fbeta_weighted(true, pred): #shapes (batch, 4)
    beta = 2
    #for metrics include these two lines, for loss, don't include them
    #these are meant to round 'pred' to exactly zeros and ones
    #predLabels = K.argmax(pred, axis=-1)
    #pred = K.one_hot(predLabels, 4) 

    ground_positives = K.sum(true, axis=0) + K.epsilon()       # = TP + FN
    pred_positives = K.sum(pred, axis=0) + K.epsilon()         # = TP + FP
    true_positives = K.sum(true * pred, axis=0) + K.epsilon()  # = TP
        #all with shape (4,)
    
    precision = true_positives / pred_positives 
    recall = true_positives / ground_positives
        #both = 1 if ground_positives == 0 or pred_positives == 0
        #shape (4,)

    # f_bata = 2 * (precision * recall) / (precision + recall + K.epsilon())
        #still with shape (4,)
    
    f_bata = (1 + beta**2) * ((precision * recall) / ((beta**2 * precision) + recall + K.epsilon()))

    weighted_fbeta = f_bata * ground_positives / K.sum(ground_positives) 
    weighted_fbeta = K.sum(weighted_fbeta)

    
    return 1 - weighted_fbeta #for metrics, return only 'weighted_fbeta'

def fbeta_loss(y_true,y_pred):
    beta = 2
    #tf.print('0', y_true)
    y_true = tf.squeeze(y_true)
    #tf.print('1', y_true)
    y_true = K.one_hot(y_true, 2)
    y_pred = K.softmax(y_pred, axis=1)
    #tf.print('2',y_true)
    #tf.print('3',y_pred)
    #tf.print('4',y_true * y_pred)
    #tf.print('5',K.sum(y_true * y_pred, axis=0))
    #y_true = K.cast(y_true, 'float')
    #y_pred = K.cast(y_pred, 'float')   
    tp = K.sum(y_true * y_pred, axis=0)
    tn = K.sum((1 - y_true) * (1 - y_pred), axis=0)
    fp = K.sum((1 - y_true) * y_pred, axis=0)
    fn = K.sum(y_true * (1 - y_pred), axis=0)

    precision = tp / (tp + fp + K.epsilon())
    recall = tp / (tp + fn + K.epsilon())
    #tf.print('precision',precision)
    #tf.print('recall',recall)
    # precision = tp / (tp + fp)
    # recall = tp / (tp + fn)

    f_bata = (1 + beta**2) * ((precision * recall) / (((beta**2) * precision) + recall + K.epsilon()))
    #tf.print('f_bata',f_bata)
    # f_bata = (1+beta**2) * (precision * recall) / ((beta**2)*precision + recall)
    #f_bata = tf.where(tf.math.is_nan(f_bata), tf.zeros_like(f_bata), f_bata)
    #tf.print('fbetaloss')
    #tf.print(1 - np.mean(f_bata))
    #ff=np.array(f_bata)
    return 1 - tf.math.reduce_mean(f_bata)

def fbeta_test(y_true, y_pred):
    metric = tfa.metrics.FBetaScore(num_classes=2, beta=2.0)

    print(y_true[0][0])
    print(y_true[1][0])
    print(y_pred[0][0])
    print(y_pred[1][0])
    print(tf.shape(y_true[1]))
    print(tf.shape(y_pred[1]))
    #y_true = K.one_hot(y_true, 2)
    y_pred = K.softmax(y_pred, axis=1)
    print(tf.shape(y_true))
    print(tf.shape(y_pred))
    metric.update_state(y_true, y_pred)
    fb = metric.result()
    return 1-fb

def fbeta(y_true,y_pred):
    beta = 2
    y_true = tf.squeeze(y_true)
    y_true = K.one_hot(y_true, 2)
    y_pred = K.softmax(y_pred, axis=1)
    #y_true = K.cast(y_true, 'float')
    #y_pred = K.cast(y_pred, 'float')   
    
    tp = K.sum(y_true * y_pred, axis=0)
    tn = K.sum((1 - y_true) * (1 - y_pred), axis=0)
    fp = K.sum((1 - y_true) * y_pred, axis=0)
    fn = K.sum(y_true * (1 - y_pred), axis=0)

    precision = tp / (tp + fp + K.epsilon())
    recall = tp / (tp + fn + K.epsilon())
    # precision = tp / (tp + fp)
    # recall = tp / (tp + fn)

    f_bata = (1 + beta**2) * ((precision * recall) / (((beta**2) * precision) + recall + K.epsilon()))
    # f_bata = (1+beta**2) * (precision * recall) / ((beta**2)*precision + recall)
    #f_bata = tf.where(tf.math.is_nan(f_bata), tf.zeros_like(f_bata), f_bata)


    return tf.math.reduce_mean(f_bata)

def f1_loss(y_true, y_pred):
    y_true = tf.squeeze(y_true)

    y_true = K.one_hot(y_true, 2)
    y_pred = K.softmax(y_pred, axis=1)

    tp = K.sum(K.cast(y_true*y_pred, 'float'), axis=0)
    tn = K.sum(K.cast((1-y_true)*(1-y_pred), 'float'), axis=0)
    fp = K.sum(K.cast((1-y_true)*y_pred, 'float'), axis=0)
    fn = K.sum(K.cast(y_true*(1-y_pred), 'float'), axis=0)

    p = tp / (tp + fp + K.epsilon())
    r = tp / (tp + fn + K.epsilon())

    f1 = 2*p*r / (p+r+K.epsilon())
    f1 = tf.where(tf.math.is_nan(f1), tf.zeros_like(f1), f1)

    
    return 1 - K.mean(f1)

def vgg_model2():
    model = tf.keras.models.Sequential()
    model.add(tf.keras.layers.Conv2D(filters=2,
                                     kernel_size=(3, 1),
                                     strides=(1, 1),
                                     padding='same', #?
                                     activation=tf.keras.activations.relu,
                                     input_shape=(1, 1250, 1)))
    model.add(tf.keras.layers.MaxPool2D(pool_size=(1, 5), ###(5, 1) or (1, 5)?
                                        strides=(1, 5))) ###(5, 1) or (1, 5)?
    model.add(tf.keras.layers.Conv2D(filters=4,
                                     kernel_size=(3, 1),
                                     strides=(1, 1),
                                     padding='same',
                                     activation=tf.keras.activations.relu))
    model.add(tf.keras.layers.MaxPool2D(pool_size=(1, 5), ###(5, 1) or (1, 5)?
                                        strides=(1, 5))) ###(5, 1) or (1, 5)?
    model.add(tf.keras.layers.Conv2D(filters=8,
                                     kernel_size=(3, 1),
                                     strides=(1, 1),
                                     padding='same',
                                     activation=tf.keras.activations.relu))
    model.add(tf.keras.layers.Conv2D(filters=8,
                                     kernel_size=(3, 1),
                                     strides=1,
                                     padding='same',
                                     activation=tf.keras.activations.relu))
    model.add(tf.keras.layers.MaxPool2D(pool_size=(1, 5), ###(5, 1) or (1, 5)?
                                        strides=(1, 5))) ###(5, 1) or (1, 5)?
    model.add(tf.keras.layers.Dropout(0.5))
    model.add(tf.keras.layers.Flatten())
    model.add(tf.keras.layers.Dense(units=9,
                                    activation=tf.keras.activations.relu))
    model.add(tf.keras.layers.Dense(units=2,
                                    activation=None))
    return model

def vgg_model():

    model = tf.keras.Sequential()
    
    model.add(tf.keras.layers.Conv2D(filters=2,
                                     kernel_size=(3, 1),
                                     strides=(1, 1),
                                     padding='same',
                                     data_format = 'channels_first',
                                     activation=tf.keras.activations.relu,
                                     input_shape=(1, 1250, 1)))

    model.add(tf.keras.layers.MaxPool2D(pool_size=(1, 5),
                                        strides=(1, 5)))

    model.add(tf.keras.layers.Conv2D(filters=4,
                                     kernel_size=(3, 1),
                                     strides=(1, 1),
                                     padding='same',
                                     data_format = 'channels_first',
                                     activation=tf.keras.activations.relu))

    model.add(tf.keras.layers.MaxPool2D(pool_size=(1, 5),
                                        strides=(1, 5)))

    model.add(tf.keras.layers.Conv2D(filters=8,
                                     kernel_size=(3, 1),
                                     strides=(1, 1),
                                     padding='same',
                                     data_format = 'channels_first',
                                     activation=tf.keras.activations.relu))

    model.add(tf.keras.layers.Conv2D(filters=8,
                                     kernel_size=(3, 1),
                                     strides=1,
                                     padding='same',
                                     data_format = 'channels_first',
                                     activation=tf.keras.activations.relu))

    model.add(tf.keras.layers.MaxPool2D(pool_size=(1, 5),
                                        strides=(1, 5)))

    model.add(tf.keras.layers.Dropout(0.5))
    model.add(tf.keras.layers.Flatten())

    model.add(tf.keras.layers.Dense(units=9,
                                    activation=tf.keras.activations.relu))
    model.add(tf.keras.layers.Dense(units=2,
                                    activation=None))

    return model

def model_evaluation(predict,y_tset):
    test_label=deepcopy(predict)
    fp = 0
    fn = 0
    tp = 0
    tn = 0
    result=0
    for i in range(0,5625):
        if test_label[i][0]>test_label[i][1]:
            result = 0
        else:
            result = 1
        if result == 0 and y_test[i] == 0:
            tn = tn + 1
        if result == 0 and y_test[i] == 1:
            fn = fn + 1
        if result == 1 and y_test[i] == 0:
            fp = fp + 1
        if result == 1 and y_test[i] == 1:
            tp = tp + 1
    total = tn + tp + fn + fp
    acc = (tp + tn) / total
    recall = tp / (tp + fn)
    precision = tp / (tp + fp)
    f1 = (1+2**2) * (precision * recall) / ((2**2)*precision + recall)
    print("F-B = ", f1)
    print("Sensitivity = ", recall)
    print("ACC = ", acc)
    print("Precision = ", precision)


def main():
    (x_train, y_train, x_test, y_test)=tfload()

    model = vgg_model()
    model.summary()
    optimizer=tf.keras.optimizers.Adam()
    fn_loss = fbeta_loss
    #fn_loss = tf.keras.losses.SparseCategoricalCrossentropy(from_logits=True)
    
    model.compile(optimizer, loss = fn_loss, metrics=['acc'])
    history=model.fit(x_train, y_train, batch_size = 256, epochs=300, validation_data = (x_test, y_test))
    print(history.history)
    tf.keras.models.save_model(model, "./tf_model")
    converter = tf.lite.TFLiteConverter.from_saved_model("./tf_model")
    tflite_model = converter.convert()
    with open('model.tflite', 'wb') as f:
        f.write(tflite_model)
    print(model.evaluate(x_test, y_test))
    y_predict=model.predict(x_test)
    tf.print('fbeta is:', fbeta(y_test, y_predict))



    #metric = tf.metrics.FBetaScore(num_classes=2, beta=2.0)
    #metric.update_state(y_true, y_pred)
    #result = metric.result()
    #result.numpy()

if __name__ == '__main__':
    main()
